const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');

const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(bodyParser.json());

// Configuración de la conexión a la base de datos
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',  // Por defecto, XAMPP no tiene contraseña para el usuario root
    database: 'score'
  });

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conexión a la base de datos establecida');
});

// Ruta para guardar la puntuación
app.post('/save-score', (req, res) => {
  const { player, score } = req.body;
  const query = 'INSERT INTO scores (player, score) VALUES (?, ?)';
  
  connection.query(query, [player, score], (err, result) => {
    if (err) {
      console.error('Error al guardar la puntuación:', err);
      res.status(500).json({ error: 'Error al guardar la puntuación' });
      return;
    }
    res.json({ message: 'Puntuación guardada correctamente' });
  });
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});